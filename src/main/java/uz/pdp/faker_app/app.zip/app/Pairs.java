package uz.pdp.faker_app.app;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class Pairs {
    private String field_name;
    private FieldType field_type;

}
